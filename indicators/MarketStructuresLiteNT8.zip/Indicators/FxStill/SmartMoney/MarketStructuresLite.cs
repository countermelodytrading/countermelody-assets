#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

///+--------------------------------------------------------------------------------------------------+
///|   Site:     https://fxstill.com                                                                  |
///|   Telegram: https://t.me/fxstill (Literature on cryptocurrencies, development and code. )        |
///|                                   Don't forget to subscribe!                                     |
///|   YouTube:  https://www.youtube.com/@FxStill                                                     |
///+--------------------------------------------------------------------------------------------------+


//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.FxStill.SmartMoney
{
	public class MarketStructuresLite : Indicator
	{
		private double dUp, dDw;
		private DateTime dtUp, dtDw;
		private bool bUp, bDw;
		private int    MinBar;
		private double delta;
		private NinjaTrader.Gui.Tools.SimpleFont myFont;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This indicator will indicate a Breaking Structure (BOS). Development: https://fxstill.com and https://t.me/fxstill.";
				Name										= "MarketStructuresLite";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Period					                    = 10;
				bLbl                                        = true;
				iDist                                       = 10;
				iFontSz                                     = 14;
				BuyClr                                      = Brushes.DodgerBlue;
				SellClr                                     = Brushes.Crimson;
				iWdth                                       = 2;
				eStyle                                      = DashStyleHelper.Solid;
			}
			else if (State == State.Configure)
			{
				ClearOutputWindow(); 
				MinBar  = 2 * Period + 1;
				delta = iDist * TickSize;
				bUp = bDw = false;
				myFont = new NinjaTrader.Gui.Tools.SimpleFont("Arial", iFontSz);
			}
		}

		protected override void OnBarUpdate() 		{
		
			
			if (CurrentBar <= MinBar) {
				dDw = Low[0];
				dUp = High[0];
				return;
			}	
			
			FindBosLine();
			FindPointSwing();

		} // protected override void OnBarUpdate()
		
		protected void FindBosLine() {
   			if (bUp) {
      			if (High[0] >= dUp) {
         			bUp = false;
					Draw.Line(this, "BosUp" + CurrentBar, true, dtUp, dUp, Time[0], dUp, BuyClr, eStyle, iWdth);
					Draw.Text(this,"BoSUpL" + CurrentBar, false, "BoS", 0, dUp + delta, 5, BuyClr, myFont, TextAlignment.Right, null, null, 1);
      			}
   			}
   			if (bDw) {
      			if (Low[0] <= dDw) {
         			bDw = false;
					Draw.Line(this, "BosDw" + CurrentBar, true, dtDw, dDw, Time[0], dDw, SellClr, eStyle, iWdth);
					Draw.Text(this,"BoSDwL" + CurrentBar, false, "BoS", 0, dDw - delta, 5, SellClr, myFont, TextAlignment.Right, null, null, 1);
      			}
   			}
		}//void FindBosLine()		
		
		protected void FindPointSwing() {
 		    int z, y;
			bool   fr_up = true, fr_dw = true;
			
			for(int j = 1; j <= Period; j++) {
      			z = Period - j;
      			y = Period + j;
      			if (fr_up) {
         			if( (High[Period] <= High[z]) || (High[Period] < High[y]) ) {
            			fr_up = false;
	         		}
      			}
      			if (fr_dw) {
         			if( (Low[Period] >= Low[z]) || (Low[Period] > Low[y]) ) {
            			fr_dw = false;
         			}
      			}				
			}// for(int j = 1; j < Period; j++)

		    if(fr_up) {
				if (bLbl) {
					if (High[Period] >= dUp)
						Draw.Text(this,"swHH" + CurrentBar, false, "HH", Period, High[Period] + delta, 5, BuyClr, myFont, TextAlignment.Center, null, null, 1);
					else
						Draw.Text(this,"swLH" + CurrentBar, false, "LH", Period, High[Period] + delta, 5, BuyClr, myFont, TextAlignment.Center, null, null, 1);
				}
				dUp   = High[Period];
				dtUp  = Time[Period];
				bUp = true;
			}
		    if(fr_dw) {
				if (bLbl) {
					if (Low[Period] <= dDw)
						Draw.Text(this,"swLL" + CurrentBar, false, "LL", Period, Low[Period] - delta, 5, SellClr, myFont, TextAlignment.Center, null, null, 1);
					else
						Draw.Text(this,"swHL" + CurrentBar, false, "HL", Period, Low[Period] - delta, 5, SellClr, myFont, TextAlignment.Center, null, null, 1);
				}
				dDw   = Low[Period]; 
				dtDw  = Time[Period];
				bDw = true;
			}
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(3, int.MaxValue)]
		[Display(Name="Period", Description="Period swing calculation", Order=1, GroupName="Parameters")]
		public int Period
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Draw Label", Description="Draw Swing Label", Order=1, GroupName="View")]
		public bool bLbl
		{ get; set; }			
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Label's Distance", Description="Label's Distance", Order=2, GroupName="View")]
		public int iDist
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Range(5, int.MaxValue)]
		[Display(Name="Label's Font Size", Description="Label's Font Size", Order=3, GroupName="View")]
		public int iFontSz
		{ get; set; }	
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Long Color", Order=4, GroupName="View")]
		public Brush BuyClr
		{ get; set; }

		[Browsable(false)]
		public string BuyClrSerializable
		{
			get { return Serialize.BrushToString(BuyClr); }
			set { BuyClr = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Short Color", Order=5, GroupName="View")]
		public Brush SellClr
		{ get; set; }

		[Browsable(false)]
		public string SellClrSerializable
		{
			get { return Serialize.BrushToString(SellClr); }
			set { SellClr = Serialize.StringToBrush(value); }
		}		
		
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Width", Order=6, GroupName="View")]
		public int iWdth
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Display(Name="Line's Style", Order=7, GroupName="View")]
		public DashStyleHelper eStyle
		{ get; set; }				
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private FxStill.SmartMoney.MarketStructuresLite[] cacheMarketStructuresLite;
		public FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return MarketStructuresLite(Input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}

		public FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(ISeries<double> input, int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			if (cacheMarketStructuresLite != null)
				for (int idx = 0; idx < cacheMarketStructuresLite.Length; idx++)
					if (cacheMarketStructuresLite[idx] != null && cacheMarketStructuresLite[idx].Period == period && cacheMarketStructuresLite[idx].bLbl == bLbl && cacheMarketStructuresLite[idx].iDist == iDist && cacheMarketStructuresLite[idx].iFontSz == iFontSz && cacheMarketStructuresLite[idx].BuyClr == buyClr && cacheMarketStructuresLite[idx].SellClr == sellClr && cacheMarketStructuresLite[idx].iWdth == iWdth && cacheMarketStructuresLite[idx].eStyle == eStyle && cacheMarketStructuresLite[idx].EqualsInput(input))
						return cacheMarketStructuresLite[idx];
			return CacheIndicator<FxStill.SmartMoney.MarketStructuresLite>(new FxStill.SmartMoney.MarketStructuresLite(){ Period = period, bLbl = bLbl, iDist = iDist, iFontSz = iFontSz, BuyClr = buyClr, SellClr = sellClr, iWdth = iWdth, eStyle = eStyle }, input, ref cacheMarketStructuresLite);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return indicator.MarketStructuresLite(Input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}

		public Indicators.FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(ISeries<double> input , int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return indicator.MarketStructuresLite(input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return indicator.MarketStructuresLite(Input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}

		public Indicators.FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(ISeries<double> input , int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return indicator.MarketStructuresLite(input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}
	}
}

#endregion
