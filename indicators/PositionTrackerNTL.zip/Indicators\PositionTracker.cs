//Disclosure
//Futures trading and strategy trading involves substantial risk and the potential for loss of capital. 
//The performance results of a trading strategy developed on the NinjaTrader platform may not be indicative of future real-time trading performance. 
//Sample strategies and indicators provided by NinjaTrader, LLC are designed to teach strategy trading and development concepts.
//All NinjaScript code contained herein is provided by NinjaTrader, LLC and is for educational and demonstrational purposes only.
//You alone are responsible for the trading decisions that you make.

//Developed June 2025
//FuturesInfo : Indicator = Version 1.3 (Updated with Location Persistamce)
//FuturesInfo : Indicator = Version 1.4 (Points Only Mode)
//Copyright(c) 2025 NinjaTrader, LLC

#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows.Input;       // For mouse event handling
using System.Windows.Threading;   // for DispatcherTimer
using System.Xml.Serialization;
using NinjaTrader.Cbi;            // for Account
using NinjaTrader.Data;           // for AccountNameConverter
using NinjaTrader.NinjaScript;    // for Indicator
using NinjaTrader.Gui;            // for Serialize class
#endregion

namespace NinjaTrader.NinjaScript.Indicators.NinjaTraderLive
{
    /// <summary>
    /// Position Tracker indicator for NinjaTrader - displays current positions and P/L in a floating window.
    /// Designed for trading livestreams with configurable colors, fonts and position.
    /// </summary>
    public class PositionTracker : Indicator
    {
        #region Private Fields
        private Window infoDialog;             // The floating dialog window that displays positions
        private bool dialogCreated = false;    // Flag to track if dialog has been created
        private DispatcherTimer _timer;        // Timer for updating position information
        private Account _account;              // The trading account to track
        private bool _timerStarted;            // Flag to prevent multiple timers
        private StackPanel positionsPanel;     // Container for position information
        #endregion

        #region Properties
        [NinjaScriptProperty]
        [Display(Name="Account", GroupName="Parameters", Order=0)]
        [TypeConverter(typeof(AccountNameConverter))]
        public string AccountName { get; set; }

        [NinjaScriptProperty]
        [Display(Name="Symbol Override", Description="Override chart symbol (leave blank to use chart symbol)", GroupName="Parameters", Order=1)]
        public string SymbolOverride { get; set; }

        [NinjaScriptProperty]
        [Display(Name="Track All Positions", Description="Show all positions in the account", GroupName="Parameters", Order=2)]
        public bool TrackAllPositions { get; set; }
		
        [NinjaScriptProperty]
        [Display(Name="Show Dollars", Description="Show profit/loss in dollars", GroupName="Parameters", Order=3)]
        public bool ShowDollars { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name="Show Points", Description="Show profit/loss in points", GroupName="Parameters", Order=4)]
        public bool ShowPoints { get; set; }

        [NinjaScriptProperty]
        [Range(1, 60)]
        [Display(Name="Update Frequency (seconds)", Description="How often to update the position information", GroupName="Parameters", Order=5)]
        public int UpdateFrequency { get; set; }

        // Color properties with serialization support
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="Positive Value Color", Description="Color for long positions and positive P&L", GroupName="Parameters", Order=6)]
        public Brush PositiveValueColor { get; set; }
        [Browsable(false)]
        public string PositiveValueColorSerializable
        {
            get => Serialize.BrushToString(PositiveValueColor);
            set => PositiveValueColor = Serialize.StringToBrush(value);
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="Negative Value Color", Description="Color for short positions and negative P&L", GroupName="Parameters", Order=7)]
        public Brush NegativeValueColor { get; set; }
        [Browsable(false)]
        public string NegativeValueColorSerializable
        {
            get => Serialize.BrushToString(NegativeValueColor);
            set => NegativeValueColor = Serialize.StringToBrush(value);
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="Background Color", Description="Background color for the info window", GroupName="Parameters", Order=8)]
        public Brush BackgroundColor { get; set; }
        [Browsable(false)]
        public string BackgroundColorSerializable
        {
            get => Serialize.BrushToString(BackgroundColor);
            set => BackgroundColor = Serialize.StringToBrush(value);
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="SymbolColor", Description="Symbol color for the info window", GroupName="Parameters", Order=9)]
        public Brush SymbolColor { get; set; }
        [Browsable(false)]
        public string SymbolColorSerializable
        {
            get => Serialize.BrushToString(SymbolColor);
            set => SymbolColor = Serialize.StringToBrush(value);
        }
			
        [NinjaScriptProperty]
        [Range(12, 36)]
        [Display(Name="Font Size", Description="Font size for better visibility on stream", GroupName="Parameters", Order=10)]
        public int FontSize { get; set; }

        [NinjaScriptProperty]
        [Range(50, 800)]
        [Display(Name="Dialog Width", Description="Width of the dialog window", GroupName="Parameters", Order=11)]
        public int DialogWidth { get; set; }

        [NinjaScriptProperty]
        [Range(50, 800)]
        [Display(Name="Dialog Height", Description="Height of the dialog window", GroupName="Parameters", Order=12)]
        public int DialogHeight { get; set; }

        // Dialog position parameters
        [NinjaScriptProperty]
        [Range(-5200, 8100)]
        [Display(Name="Dialog Left", Description="Horizontal position of the dialog (pixels)", GroupName="Parameters", Order=13)]
        public double DialogLeft { get; set; }

        [NinjaScriptProperty]
        [Range(-2200, 2200)]
        [Display(Name="Dialog Top", Description="Vertical position of the dialog (pixels)", GroupName="Parameters", Order=14)]
        public double DialogTop { get; set; }

        // UI customization
        [NinjaScriptProperty]
        [Range(1,20)]
        [Display(Name="Drag Handle Height", GroupName="Parameters", Order=15)]
        public int DragHandleHeight { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="Drag Handle Color", Description="Color for the window drag handle", GroupName="Parameters", Order=16)]
        public Brush DragHandleColor { get; set; }
        [Browsable(false)]
        public string DragHandleColorSerializable
        {
            get => Serialize.BrushToString(DragHandleColor);
            set => DragHandleColor = Serialize.StringToBrush(value);
        }
		
        [XmlIgnore]
        [Display(Name="Header Color", GroupName="Parameters", Order=17)]
        public Brush HeaderColor { get; set; }
        [Browsable(false)]
        public string HeaderColorSerializable
        {
            get => Serialize.BrushToString(HeaderColor);
            set => HeaderColor = Serialize.StringToBrush(value);
        }
        #endregion

        #region Core Methods
        /// <summary>
        /// Primary lifecycle method for the indicator, handles state transitions
        /// </summary>
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                // Set default values for all parameters
                Description        = "Streamlined position tracker for trading livestreams";
                Name               = "PositionTracker";
                Calculate          = Calculate.OnBarClose;
                IsOverlay          = true;
                AccountName        = string.Empty;
                SymbolOverride     = string.Empty;
                TrackAllPositions  = false;
                UpdateFrequency    = 2;
                PositiveValueColor = Brushes.Green;
                NegativeValueColor = Brushes.Red;
                BackgroundColor    = Brushes.Black;
                SymbolColor        = Brushes.White;
                FontSize           = 22;
                DialogWidth        = 450;
                DialogHeight       = 140;
                
                // Only set default position if not already set
                // This prevents resetting position when indicator properties change
                if (DialogLeft == 0 && DialogTop == 0)
                {
                    DialogLeft = 500;
                    DialogTop = 500;
                }
        
                DragHandleHeight   = 1;              // default tiny header
                DragHandleColor    = Brushes.DarkGray;
                HeaderColor        = Brushes.DarkGray;
                AddPlot(Brushes.Transparent, "Hidden");
                _timerStarted      = false;
                ShowDollars        = true;           // Show dollars by default
                ShowPoints         = false;          // Don't show points by default
            }
            else if (State == State.Configure)
            {
                // Clear name to avoid showing in legend
                Name = "";
            }
            else if (State == State.Historical)
            {
                // Initialize when chart loads historical data
                
                // Resolve account - find the account by name
                _account = null;
                if (!string.IsNullOrEmpty(AccountName))
                    _account = Account.All.FirstOrDefault(a => a.Name == AccountName);

                // Create the floating dialog
                CreateInfoDialog();

                // Set up position update timer
                if (!_timerStarted && ChartControl != null)
                {
                    _timer = new DispatcherTimer(
                        TimeSpan.FromSeconds(UpdateFrequency),
                        DispatcherPriority.Normal,
                        Timer_Tick,
                        ChartControl.Dispatcher);
                    _timer.Start();
                    _timerStarted = true;
                }
            }
            else if (State == State.Terminated)
            {
                // Clean up resources when indicator is removed
                if (_timer != null)
                {
                    _timer.Stop();
                    _timer.Tick -= Timer_Tick;
                    _timer = null;
                }
                _timerStarted = false;

                if (infoDialog != null)
                {
                    Dispatcher.InvokeAsync(() =>
                    {
                        infoDialog.Closing -= Window_Closing;
                        infoDialog.Close();
                        infoDialog = null;
                    });
                }
            }
        }

        /// <summary>
        /// Creates the floating dialog window that displays position information
        /// </summary>
        private void CreateInfoDialog()
        {
            Dispatcher.InvokeAsync(() =>
            {
                // If dialog already exists, just show it
                if (infoDialog != null)
                {
                    infoDialog.Show();
                    return;
                }
			
                // Create the window with appropriate styling
                infoDialog = new Window
                {
                    Title                 = "Stream Position Tracker",
                    Width                 = DialogWidth,
                    Height                = DialogHeight,
                    WindowStyle           = WindowStyle.None,  // No standard window border
                    ResizeMode            = ResizeMode.CanResize,
                    ShowInTaskbar         = false,
                    Topmost               = true,  // Stay on top of other windows
                    Background            = BackgroundColor,
                    WindowStartupLocation = WindowStartupLocation.Manual
                };
			
                // Calculate screen position relative to chart
                var chartOrigin = ChartControl.PointToScreen(new Point(0, 0));
                double chartX      = chartOrigin.X;
                double chartY      = chartOrigin.Y;
                double chartW      = ChartControl.ActualWidth;
                double chartH      = ChartControl.ActualHeight;
			
                // Use saved position if available, otherwise center on chart
                if (DialogLeft  >=  -5200 && DialogLeft  <=  8100 &&
                    DialogTop   >=  -2200 && DialogTop   <=  2200)
                {
                    infoDialog.Left = DialogLeft;
                    infoDialog.Top  = DialogTop;
                }
                else
                {
                    // Center dialog over chart area
                    infoDialog.Left = chartX + (chartW - DialogWidth)  / 2;
                    infoDialog.Top  = chartY + (chartH - DialogHeight) / 2;
                }
			
                // Create content panel for position information
                positionsPanel = new StackPanel { Margin = new Thickness(10) };
                infoDialog.Content = positionsPanel;
			
                // Hide instead of close when X is clicked
                infoDialog.Closing += (s, e) =>
                {
                    e.Cancel = true;
                    infoDialog.Hide();
                };
			
                // Allow window dragging by clicking anywhere
                infoDialog.PreviewMouseLeftButtonDown += (s, e) =>
                {
                    infoDialog.DragMove();
                };
			
                // Save position when window is moved
                infoDialog.LocationChanged += (s, e) =>
                {
								
                    try
                    {
                        // Save dialog position with bounds checking
                        DialogLeft = Math.Max(-5200, Math.Min(infoDialog.Left, 8100));
                        DialogTop = Math.Max(-2200, Math.Min(infoDialog.Top, 2200));
                    }
                    catch (Exception ex)
                    {
                        // Log error and reset to default position if an exception occurs
                        System.Diagnostics.Debug.WriteLine($"Error saving dialog position: {ex.Message}");
                        
                        // DialogLeft = 500;
                        // DialogTop = 500;
                    }
                };
					
                // Save size when window is resized
                infoDialog.SizeChanged += (s, e) =>
                {
                    DialogWidth = (int)Math.Max(50, Math.Min(infoDialog.ActualWidth, 1000));
                    DialogHeight = (int)Math.Max(50, Math.Min(infoDialog.ActualHeight, 1000));
                };
			
                // Show the dialog and perform initial update
                infoDialog.Show();
                Timer_Tick(null, null);
            });
        }
			
        /// <summary>
        /// Event handler for dialog closing - prevents actual closing, just hides the window
        /// </summary>
        private void Window_Closing(object sender, CancelEventArgs e)
        {
            e.Cancel = true;
            infoDialog.Hide();
        }
			
        /// <summary>
        /// Timer callback that updates position information
        /// </summary>
        private void Timer_Tick(object sender, EventArgs e)
        {
            Dispatcher.InvokeAsync(() =>
            {
                // Clear previous content
                positionsPanel.Children.Clear();
                
                // Display message if no account is selected
                if (_account == null)
                {
                    positionsPanel.Children.Add(new Label {
                        Content             = "Select an Account from the Properties",
                        FontSize            = 20,  // 20pt as requested
                        FontWeight          = FontWeights.Bold,
                        Foreground          = Brushes.Yellow,  // Yellow as requested
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Padding             = new Thickness(5, 0, 5, 0), 
                    });
                    return;
                }
			
                bool positionFound = false;
			
                if (TrackAllPositions)
                {
                    // Show all positions in the account
                    foreach (var pos in _account.Positions)
                    {
                        if (pos.MarketPosition != MarketPosition.Flat)
                        {
                            AddPositionRow(pos);
                            positionFound = true;
                        }
                    }
                    
                    // Show "No Positions" if account has no open positions
                    if (!positionFound)
                        positionsPanel.Children.Add(new Label {
                            Content             = "No Positions",
                            FontSize            = FontSize,
                            FontWeight          = FontWeights.Bold,
                            Foreground          = SymbolColor,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            Padding = new Thickness(5, 0, 5, 0),
                        });
                }
                else
                {
                    // Show only the position for the current chart or overridden symbol
                    Position target = null;
                    if (!string.IsNullOrEmpty(SymbolOverride))
                        target = _account.Positions.FirstOrDefault(p => p.Instrument.FullName.Contains(SymbolOverride));
                    else if (ChartControl?.Instrument != null)
                        target = _account.Positions.FirstOrDefault(p => p.Instrument == ChartControl.Instrument);
			
                    if (target != null && target.MarketPosition != MarketPosition.Flat)
                        AddPositionRow(target);
                    else
                    {
                        // Show "No Position" message when no position exists for the symbol
                        string sym = !string.IsNullOrEmpty(SymbolOverride)
                                    ? SymbolOverride
                                    : ChartControl?.Instrument?.MasterInstrument?.Name ?? "Unknown";
                        positionsPanel.Children.Add(new Label {
                            Content             = $"No Position: {sym}",
                            FontSize            = FontSize,
                            FontWeight          = FontWeights.Bold,
                            Foreground          = SymbolColor,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            Padding = new Thickness(5, 0, 5, 0),
                        });
                    }
                }
            });
        }

        /// <summary>
        /// Creates and adds a UI row for a single position
        /// </summary>
        /// <param name="position">The position to display</param>
        private void AddPositionRow(Position position)
        {
            // Validate position
            if (position == null || position.MarketPosition == MarketPosition.Flat)
                return;
            
            // Determine if we should show P/L column
            bool showPLColumn = ShowDollars || ShowPoints;
			
            // Create grid layout for the position row
            var grid = new Grid();
            
            // Define column structure with auto-sizing
            // Column 0: Position type (LONG/SHORT) - auto size to content
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            
            // Column 1: Symbol - takes remaining space
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            
            // Column 2: P/L - auto size to content (only if needed)
            if (showPLColumn)
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
				
            // Create position type label (LONG/SHORT)
            var posLabel = new Label {
                FontSize            = FontSize,
                FontWeight          = FontWeights.Bold,
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Left,
                Padding = new Thickness(10, 2, 15, 2), // Extra right padding for separation
            };
            
            // Format position based on direction
            if (position.MarketPosition == MarketPosition.Long)
            {
                posLabel.Content    = $"LONG {Math.Abs(position.Quantity)}";
                posLabel.Foreground = PositiveValueColor;
            }
            else
            {
                posLabel.Content    = $"SHORT {Math.Abs(position.Quantity)}";
                posLabel.Foreground = NegativeValueColor;
            }
            Grid.SetColumn(posLabel, 0);
            grid.Children.Add(posLabel);
			
            // Extract symbol root (just the base symbol without contract details)
            string symbol = position.Instrument.MasterInstrument.Name;
            
            // Create symbol label
            var symLabel = new Label {
                Content             = symbol,
                FontSize            = FontSize,
                FontWeight          = FontWeights.Bold,
                Foreground          = SymbolColor,
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Padding = new Thickness(5, 2, 5, 2),
            };
            Grid.SetColumn(symLabel, 1);
            grid.Children.Add(symLabel);
			
            // Only add P/L if at least one display option is enabled
            if (showPLColumn)
            {
                // Calculate profit/loss values
                double pl = position.GetUnrealizedProfitLoss(PerformanceUnit.Currency);
                double pointValue = position.Instrument.MasterInstrument.PointValue;
                double points = pl / Math.Abs(position.Quantity) / pointValue;
                
                // Calculate decimal places based on tick size
                double tickSize = position.Instrument.MasterInstrument.TickSize;
                int decimalPlaces = GetDecimalPlaces(tickSize);
                string pointsFormat = $"N{decimalPlaces}";
                
                // Create P/L label
                var plLabel = new Label {
                    FontSize            = FontSize,
                    FontWeight          = FontWeights.Bold,
                    VerticalAlignment   = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Padding = new Thickness(15, 2, 10, 2), // Extra left padding for separation
                };
                
                // Format P/L content based on display settings
                string plContent = "";
                
                if (ShowDollars && ShowPoints)
                {
                    // Show both dollars and points (with parentheses)
                    if (pl >= 0)
                        plContent = $"${pl:N0} ({points.ToString(pointsFormat)})";
                    else
                        plContent = $"-${Math.Abs(pl):N0} ({points.ToString(pointsFormat)})";
                }
                else if (ShowDollars && !ShowPoints)
                {
                    // Show only dollars
                    if (pl >= 0)
                        plContent = $"${pl:N0}";
                    else
                        plContent = $"-${Math.Abs(pl):N0}";
                }
                else if (!ShowDollars && ShowPoints)
                {
                    // Show only points (no parentheses)
                    plContent = $"{points.ToString(pointsFormat)}";
                }
                
                // Set color based on profit/loss
                // Use yellow for break-even (zero or near-zero P/L)
                if (Math.Abs(pl) < 0.01) // Less than 1 cent is effectively zero
                    plLabel.Foreground = Brushes.Yellow;
                else if (pl > 0)
                    plLabel.Foreground = PositiveValueColor;
                else
                    plLabel.Foreground = NegativeValueColor;
                    
                plLabel.Content = plContent;
                
                Grid.SetColumn(plLabel, 2);
                grid.Children.Add(plLabel);
            }
			
            // Add row to the panel with consistent margin
            grid.Margin = new Thickness(0, 2, 0, 2); // Small vertical margin between rows
            positionsPanel.Children.Add(grid);
			
            // Add separator between positions when showing all positions
            if (TrackAllPositions && position != _account.Positions.Last(p => p.MarketPosition != MarketPosition.Flat))
            {
                positionsPanel.Children.Add(new Rectangle {
                    Height              = 1,  // Thin separator
                    Fill                = Brushes.DimGray,
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    Margin              = new Thickness(10, 5, 10, 5) // Horizontal margin for cleaner look
                });
            }
        }
        
        /// <summary>
        /// Helper method to determine the number of decimal places from tick size
        /// </summary>
        /// <param name="tickSize">The instrument's minimum price movement</param>
        /// <returns>Number of decimal places to display</returns>
        private int GetDecimalPlaces(double tickSize)
        {
            // Handle edge cases
            if (tickSize >= 1) return 0;
            if (tickSize <= 0) return 2; // Default fallback
            
            // Count decimal places by converting to string
            string tickString = tickSize.ToString("0.##########");
            int decimalIndex = tickString.IndexOf('.');
            
            if (decimalIndex < 0) return 0;
            
            return tickString.Length - decimalIndex - 1;
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private NinjaTraderLive.PositionTracker[] cachePositionTracker;
		public NinjaTraderLive.PositionTracker PositionTracker(string accountName, string symbolOverride, bool trackAllPositions, bool showDollars, bool showPoints, int updateFrequency, Brush positiveValueColor, Brush negativeValueColor, Brush backgroundColor, Brush symbolColor, int fontSize, int dialogWidth, int dialogHeight, double dialogLeft, double dialogTop, int dragHandleHeight, Brush dragHandleColor)
		{
			return PositionTracker(Input, accountName, symbolOverride, trackAllPositions, showDollars, showPoints, updateFrequency, positiveValueColor, negativeValueColor, backgroundColor, symbolColor, fontSize, dialogWidth, dialogHeight, dialogLeft, dialogTop, dragHandleHeight, dragHandleColor);
		}

		public NinjaTraderLive.PositionTracker PositionTracker(ISeries<double> input, string accountName, string symbolOverride, bool trackAllPositions, bool showDollars, bool showPoints, int updateFrequency, Brush positiveValueColor, Brush negativeValueColor, Brush backgroundColor, Brush symbolColor, int fontSize, int dialogWidth, int dialogHeight, double dialogLeft, double dialogTop, int dragHandleHeight, Brush dragHandleColor)
		{
			if (cachePositionTracker != null)
				for (int idx = 0; idx < cachePositionTracker.Length; idx++)
					if (cachePositionTracker[idx] != null && cachePositionTracker[idx].AccountName == accountName && cachePositionTracker[idx].SymbolOverride == symbolOverride && cachePositionTracker[idx].TrackAllPositions == trackAllPositions && cachePositionTracker[idx].ShowDollars == showDollars && cachePositionTracker[idx].ShowPoints == showPoints && cachePositionTracker[idx].UpdateFrequency == updateFrequency && cachePositionTracker[idx].PositiveValueColor == positiveValueColor && cachePositionTracker[idx].NegativeValueColor == negativeValueColor && cachePositionTracker[idx].BackgroundColor == backgroundColor && cachePositionTracker[idx].SymbolColor == symbolColor && cachePositionTracker[idx].FontSize == fontSize && cachePositionTracker[idx].DialogWidth == dialogWidth && cachePositionTracker[idx].DialogHeight == dialogHeight && cachePositionTracker[idx].DialogLeft == dialogLeft && cachePositionTracker[idx].DialogTop == dialogTop && cachePositionTracker[idx].DragHandleHeight == dragHandleHeight && cachePositionTracker[idx].DragHandleColor == dragHandleColor && cachePositionTracker[idx].EqualsInput(input))
						return cachePositionTracker[idx];
			return CacheIndicator<NinjaTraderLive.PositionTracker>(new NinjaTraderLive.PositionTracker(){ AccountName = accountName, SymbolOverride = symbolOverride, TrackAllPositions = trackAllPositions, ShowDollars = showDollars, ShowPoints = showPoints, UpdateFrequency = updateFrequency, PositiveValueColor = positiveValueColor, NegativeValueColor = negativeValueColor, BackgroundColor = backgroundColor, SymbolColor = symbolColor, FontSize = fontSize, DialogWidth = dialogWidth, DialogHeight = dialogHeight, DialogLeft = dialogLeft, DialogTop = dialogTop, DragHandleHeight = dragHandleHeight, DragHandleColor = dragHandleColor }, input, ref cachePositionTracker);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.NinjaTraderLive.PositionTracker PositionTracker(string accountName, string symbolOverride, bool trackAllPositions, bool showDollars, bool showPoints, int updateFrequency, Brush positiveValueColor, Brush negativeValueColor, Brush backgroundColor, Brush symbolColor, int fontSize, int dialogWidth, int dialogHeight, double dialogLeft, double dialogTop, int dragHandleHeight, Brush dragHandleColor)
		{
			return indicator.PositionTracker(Input, accountName, symbolOverride, trackAllPositions, showDollars, showPoints, updateFrequency, positiveValueColor, negativeValueColor, backgroundColor, symbolColor, fontSize, dialogWidth, dialogHeight, dialogLeft, dialogTop, dragHandleHeight, dragHandleColor);
		}

		public Indicators.NinjaTraderLive.PositionTracker PositionTracker(ISeries<double> input , string accountName, string symbolOverride, bool trackAllPositions, bool showDollars, bool showPoints, int updateFrequency, Brush positiveValueColor, Brush negativeValueColor, Brush backgroundColor, Brush symbolColor, int fontSize, int dialogWidth, int dialogHeight, double dialogLeft, double dialogTop, int dragHandleHeight, Brush dragHandleColor)
		{
			return indicator.PositionTracker(input, accountName, symbolOverride, trackAllPositions, showDollars, showPoints, updateFrequency, positiveValueColor, negativeValueColor, backgroundColor, symbolColor, fontSize, dialogWidth, dialogHeight, dialogLeft, dialogTop, dragHandleHeight, dragHandleColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.NinjaTraderLive.PositionTracker PositionTracker(string accountName, string symbolOverride, bool trackAllPositions, bool showDollars, bool showPoints, int updateFrequency, Brush positiveValueColor, Brush negativeValueColor, Brush backgroundColor, Brush symbolColor, int fontSize, int dialogWidth, int dialogHeight, double dialogLeft, double dialogTop, int dragHandleHeight, Brush dragHandleColor)
		{
			return indicator.PositionTracker(Input, accountName, symbolOverride, trackAllPositions, showDollars, showPoints, updateFrequency, positiveValueColor, negativeValueColor, backgroundColor, symbolColor, fontSize, dialogWidth, dialogHeight, dialogLeft, dialogTop, dragHandleHeight, dragHandleColor);
		}

		public Indicators.NinjaTraderLive.PositionTracker PositionTracker(ISeries<double> input , string accountName, string symbolOverride, bool trackAllPositions, bool showDollars, bool showPoints, int updateFrequency, Brush positiveValueColor, Brush negativeValueColor, Brush backgroundColor, Brush symbolColor, int fontSize, int dialogWidth, int dialogHeight, double dialogLeft, double dialogTop, int dragHandleHeight, Brush dragHandleColor)
		{
			return indicator.PositionTracker(input, accountName, symbolOverride, trackAllPositions, showDollars, showPoints, updateFrequency, positiveValueColor, negativeValueColor, backgroundColor, symbolColor, fontSize, dialogWidth, dialogHeight, dialogLeft, dialogTop, dragHandleHeight, dragHandleColor);
		}
	}
}

#endregion
