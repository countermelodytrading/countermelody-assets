#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

using EnumTimeFrame = NinjaTrader.NinjaScript.Indicators.THE_VWAP_INTRADAY.EnumTimeFrame;
using EnumVWAPColor = NinjaTrader.NinjaScript.Indicators.THE_VWAP_INTRADAY.EnumVWAPColor;
using EnumBackground_Color_Signal = NinjaTrader.NinjaScript.Indicators.THE_VWAP_INTRADAY.EnumBackground_Color_Signal;


#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private THE_VWAP_INTRADAY[] cacheTHE_VWAP_INTRADAY;

		
		public THE_VWAP_INTRADAY THE_VWAP_INTRADAY(double stDev1, double stDev2, EnumTimeFrame timeFrame, double tolerance_Band_Width)
		{
			return THE_VWAP_INTRADAY(Input, stDev1, stDev2, timeFrame, tolerance_Band_Width);
		}


		
		public THE_VWAP_INTRADAY THE_VWAP_INTRADAY(ISeries<double> input, double stDev1, double stDev2, EnumTimeFrame timeFrame, double tolerance_Band_Width)
		{
			if (cacheTHE_VWAP_INTRADAY != null)
				for (int idx = 0; idx < cacheTHE_VWAP_INTRADAY.Length; idx++)
					if (cacheTHE_VWAP_INTRADAY[idx].StDev1 == stDev1 && cacheTHE_VWAP_INTRADAY[idx].StDev2 == stDev2 && cacheTHE_VWAP_INTRADAY[idx].TimeFrame == timeFrame && cacheTHE_VWAP_INTRADAY[idx].Tolerance_Band_Width == tolerance_Band_Width && cacheTHE_VWAP_INTRADAY[idx].EqualsInput(input))
						return cacheTHE_VWAP_INTRADAY[idx];
			return CacheIndicator<THE_VWAP_INTRADAY>(new THE_VWAP_INTRADAY(){ StDev1 = stDev1, StDev2 = stDev2, TimeFrame = timeFrame, Tolerance_Band_Width = tolerance_Band_Width }, input, ref cacheTHE_VWAP_INTRADAY);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.THE_VWAP_INTRADAY THE_VWAP_INTRADAY(double stDev1, double stDev2, EnumTimeFrame timeFrame, double tolerance_Band_Width)
		{
			return indicator.THE_VWAP_INTRADAY(Input, stDev1, stDev2, timeFrame, tolerance_Band_Width);
		}


		
		public Indicators.THE_VWAP_INTRADAY THE_VWAP_INTRADAY(ISeries<double> input , double stDev1, double stDev2, EnumTimeFrame timeFrame, double tolerance_Band_Width)
		{
			return indicator.THE_VWAP_INTRADAY(input, stDev1, stDev2, timeFrame, tolerance_Band_Width);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.THE_VWAP_INTRADAY THE_VWAP_INTRADAY(double stDev1, double stDev2, EnumTimeFrame timeFrame, double tolerance_Band_Width)
		{
			return indicator.THE_VWAP_INTRADAY(Input, stDev1, stDev2, timeFrame, tolerance_Band_Width);
		}


		
		public Indicators.THE_VWAP_INTRADAY THE_VWAP_INTRADAY(ISeries<double> input , double stDev1, double stDev2, EnumTimeFrame timeFrame, double tolerance_Band_Width)
		{
			return indicator.THE_VWAP_INTRADAY(input, stDev1, stDev2, timeFrame, tolerance_Band_Width);
		}

	}
}

#endregion
