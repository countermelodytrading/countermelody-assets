#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private CrossTrendColorEMA[] cacheCrossTrendColorEMA;

		
		public CrossTrendColorEMA CrossTrendColorEMA(int fastPeriod, int slowPeriod, Brush fastBullColor, Brush fastBearColor, Brush slowBullColor, Brush slowBearColor, bool fastEMAPlot, bool slowEMAPlot)
		{
			return CrossTrendColorEMA(Input, fastPeriod, slowPeriod, fastBullColor, fastBearColor, slowBullColor, slowBearColor, fastEMAPlot, slowEMAPlot);
		}


		
		public CrossTrendColorEMA CrossTrendColorEMA(ISeries<double> input, int fastPeriod, int slowPeriod, Brush fastBullColor, Brush fastBearColor, Brush slowBullColor, Brush slowBearColor, bool fastEMAPlot, bool slowEMAPlot)
		{
			if (cacheCrossTrendColorEMA != null)
				for (int idx = 0; idx < cacheCrossTrendColorEMA.Length; idx++)
					if (cacheCrossTrendColorEMA[idx].fastPeriod == fastPeriod && cacheCrossTrendColorEMA[idx].slowPeriod == slowPeriod && cacheCrossTrendColorEMA[idx].fastBullColor == fastBullColor && cacheCrossTrendColorEMA[idx].fastBearColor == fastBearColor && cacheCrossTrendColorEMA[idx].slowBullColor == slowBullColor && cacheCrossTrendColorEMA[idx].slowBearColor == slowBearColor && cacheCrossTrendColorEMA[idx].FastEMAPlot == fastEMAPlot && cacheCrossTrendColorEMA[idx].SlowEMAPlot == slowEMAPlot && cacheCrossTrendColorEMA[idx].EqualsInput(input))
						return cacheCrossTrendColorEMA[idx];
			return CacheIndicator<CrossTrendColorEMA>(new CrossTrendColorEMA(){ fastPeriod = fastPeriod, slowPeriod = slowPeriod, fastBullColor = fastBullColor, fastBearColor = fastBearColor, slowBullColor = slowBullColor, slowBearColor = slowBearColor, FastEMAPlot = fastEMAPlot, SlowEMAPlot = slowEMAPlot }, input, ref cacheCrossTrendColorEMA);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.CrossTrendColorEMA CrossTrendColorEMA(int fastPeriod, int slowPeriod, Brush fastBullColor, Brush fastBearColor, Brush slowBullColor, Brush slowBearColor, bool fastEMAPlot, bool slowEMAPlot)
		{
			return indicator.CrossTrendColorEMA(Input, fastPeriod, slowPeriod, fastBullColor, fastBearColor, slowBullColor, slowBearColor, fastEMAPlot, slowEMAPlot);
		}


		
		public Indicators.CrossTrendColorEMA CrossTrendColorEMA(ISeries<double> input , int fastPeriod, int slowPeriod, Brush fastBullColor, Brush fastBearColor, Brush slowBullColor, Brush slowBearColor, bool fastEMAPlot, bool slowEMAPlot)
		{
			return indicator.CrossTrendColorEMA(input, fastPeriod, slowPeriod, fastBullColor, fastBearColor, slowBullColor, slowBearColor, fastEMAPlot, slowEMAPlot);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.CrossTrendColorEMA CrossTrendColorEMA(int fastPeriod, int slowPeriod, Brush fastBullColor, Brush fastBearColor, Brush slowBullColor, Brush slowBearColor, bool fastEMAPlot, bool slowEMAPlot)
		{
			return indicator.CrossTrendColorEMA(Input, fastPeriod, slowPeriod, fastBullColor, fastBearColor, slowBullColor, slowBearColor, fastEMAPlot, slowEMAPlot);
		}


		
		public Indicators.CrossTrendColorEMA CrossTrendColorEMA(ISeries<double> input , int fastPeriod, int slowPeriod, Brush fastBullColor, Brush fastBearColor, Brush slowBullColor, Brush slowBearColor, bool fastEMAPlot, bool slowEMAPlot)
		{
			return indicator.CrossTrendColorEMA(input, fastPeriod, slowPeriod, fastBullColor, fastBearColor, slowBullColor, slowBearColor, fastEMAPlot, slowEMAPlot);
		}

	}
}

#endregion
